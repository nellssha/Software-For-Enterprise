
const inputField = document.getElementById("inputField");
const submitBtn = document.getElementById("submitBtn");
const output = document.getElementById("output");
const addBtn = document.getElementById("addBtn");
const buttonContainer = document.getElementById("buttonContainer");
const buttonOutput = document.getElementById("buttonOutput");

// TASK 2 and TASK 4: Basic event handling and error handling
submitBtn.addEventListener("click", function () {
    const input = inputField.value.trim();

    if (input === "") {
        output.textContent = "Error: Input cannot be empty!";
        output.className = "error";
    } else {
        output.textContent = "You entered: " + input;
        output.className = "success";
    }
});

// TASK 3: Create buttons dynamically
let buttonCount = 0;

addBtn.addEventListener("click", function () {
    buttonCount++;

    const newButton = document.createElement("button");
    newButton.textContent = "New Button " + buttonCount;
    newButton.type = "button";
    newButton.dataset.buttonNumber = buttonCount;

    buttonContainer.appendChild(newButton);
});

// TASK 3: Event delegation
buttonContainer.addEventListener("click", function (event) {
    if (event.target.tagName === "BUTTON") {
        buttonOutput.textContent =
            "You clicked " + event.target.textContent;
    }
});

// TASK 5: Observer pattern
const observers = [
    document.getElementById("observer1"),
    document.getElementById("observer2")
];

function notifyObservers(value) {
    observers.forEach(function (observer, index) {
        observer.textContent =
            "Observer " + (index + 1) + ": Updated with: " +
            (value || "(empty input)");
    });
}

inputField.addEventListener("input", function () {
    notifyObservers(inputField.value);
});

// TASK 6: Prevent text selection
document.addEventListener("selectstart", function (event) {
    event.preventDefault();
});

// TASK 6: Prevent copying
document.addEventListener("copy", function (event) {
    event.preventDefault();
    alert("Copying is disabled on this page.");
});
